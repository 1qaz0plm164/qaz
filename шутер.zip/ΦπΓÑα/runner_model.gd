extends RefCounted
# Модель бегуна: недавно заражённый человек. Почти прямая осанка, руки вытянуты
# вперёд, рваная одежда, на лице и шее первые грибные наросты, мутные глаза.
# Возвращает те же части, что и clicker_model.gd: legs, arms, torso, head.

const TORSO_LEAN := -0.22
const ARM_BASE := 1.25        # руки тянутся к жертве

const CLOTHES := [
	Color(0.32, 0.18, 0.14), Color(0.16, 0.22, 0.3), Color(0.26, 0.27, 0.22),
	Color(0.35, 0.33, 0.3), Color(0.14, 0.14, 0.15), Color(0.3, 0.12, 0.12),
]

static func _mat(color: Color, rough := 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m

static func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 12
	s.rings = 6
	return s

static func _capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	c.radial_segments = 10
	c.rings = 4
	return c

static func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b

static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi

static func build(root: Node3D, seed_value := 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	var t := rng.randf_range(-0.04, 0.04)
	var skin := _mat(Color(0.52 + t, 0.45 + t, 0.4 + t), 0.8)          # бледная серая кожа
	var shirt := _mat(CLOTHES[rng.randi() % CLOTHES.size()] * rng.randf_range(0.8, 1.1), 0.95)
	var pants := _mat(CLOTHES[rng.randi() % CLOTHES.size()] * 0.7, 0.95)
	var shoe := _mat(Color(0.07, 0.06, 0.06), 0.8)
	var hair := _mat(Color(0.08 + t, 0.06, 0.05), 0.95)
	var fungus := _mat(Color(0.6, 0.48, 0.3), 0.7)                      # бежевые наросты
	var flesh := _mat(Color(0.45, 0.15, 0.12), 0.5)
	var eye := _mat(Color(0.85, 0.82, 0.62), 0.3)                       # мутные жёлтые глаза
	var blood := _mat(Color(0.25, 0.04, 0.04), 0.4)

	# ---------- Таз ----------
	var hips := Node3D.new()
	hips.position = Vector3(0, 0.95, 0)
	root.add_child(hips)
	_add(hips, _box(Vector3(0.34, 0.18, 0.2)), pants)

	# ---------- Ноги ----------
	var legs: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.1, 0.95, 0)
		root.add_child(leg)
		_add(leg, _capsule(0.075, 0.95), pants, Vector3(0, -0.45, 0))
		_add(leg, _box(Vector3(0.11, 0.08, 0.26)), shoe, Vector3(0, -0.9, -0.05))
		legs.append(leg)

	# ---------- Туловище ----------
	var torso := Node3D.new()
	torso.position = Vector3(0, 0.95, 0)
	torso.rotation.x = TORSO_LEAN
	root.add_child(torso)
	_add(torso, _capsule(0.17, 0.72), shirt, Vector3(0, 0.36, 0), Vector3.ZERO, Vector3(1.2, 1.0, 0.75))
	# Пятна крови и дыры на одежде
	for i in 3:
		var p := Vector3(rng.randf_range(-0.15, 0.15), rng.randf_range(0.15, 0.6), -0.13)
		_add(torso, _box(Vector3(rng.randf_range(0.05, 0.12), rng.randf_range(0.04, 0.1), 0.01)), blood, p)
	# Нарост на плече
	_add(torso, _sphere(0.06), fungus, Vector3(0.18, 0.66, 0.03), Vector3.ZERO, Vector3(1.3, 0.8, 1.0))

	# ---------- Руки ----------
	var arms: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.25, 0.64, 0)
		arm.rotation.x = ARM_BASE
		arm.rotation.z = side * 0.12
		torso.add_child(arm)
		_add(arm, _capsule(0.07, 0.36), shirt, Vector3(0, -0.15, 0))     # рукав
		_add(arm, _capsule(0.05, 0.42), skin, Vector3(0, -0.45, 0))      # предплечье
		_add(arm, _box(Vector3(0.07, 0.11, 0.035)), skin, Vector3(0, -0.72, 0))   # кисть
		for f in 4:
			_add(arm, _box(Vector3(0.012, 0.07, 0.012)), skin, Vector3((f - 1.5) * 0.017, -0.8, 0.0))
		arms.append(arm)

	# ---------- Голова: человеческое лицо, наполовину съеденное грибом ----------
	var head := Node3D.new()
	head.position = Vector3(0, 0.86, -0.02)
	head.rotation.x = 0.15
	torso.add_child(head)
	_add(head, _capsule(0.045, 0.14), skin, Vector3(0, -0.1, 0))       # шея
	_add(head, _sphere(0.115), skin, Vector3(0, 0.03, 0), Vector3.ZERO, Vector3(0.9, 1.1, 1.0))
	_add(head, _sphere(0.118), hair, Vector3(0, 0.07, 0.025), Vector3.ZERO, Vector3(0.92, 0.9, 1.0))
	# Глаза (одна сторона лица заросла)
	var grown_side := -1.0 if rng.randf() < 0.5 else 1.0
	_add(head, _sphere(0.017), eye, Vector3(-grown_side * 0.04, 0.04, -0.1))
	_add(head, _sphere(0.017), eye, Vector3(grown_side * 0.04, 0.04, -0.1))
	# Раскрытый в крике рот
	_add(head, _box(Vector3(0.05, 0.035, 0.02)), flesh, Vector3(0, -0.04, -0.1))
	# Грибные наросты, которые растут по одной стороне лица и шее
	for i in 6:
		var p := Vector3(grown_side * rng.randf_range(0.03, 0.1), rng.randf_range(-0.08, 0.1), rng.randf_range(-0.1, 0.02))
		_add(head, _sphere(rng.randf_range(0.022, 0.045)), fungus, p)
	_add(head, _sphere(0.035), flesh, Vector3(grown_side * 0.06, 0.05, -0.09), Vector3.ZERO, Vector3(1.0, 1.2, 0.6))

	return {"legs": legs, "arms": arms, "torso": torso, "head": head}
