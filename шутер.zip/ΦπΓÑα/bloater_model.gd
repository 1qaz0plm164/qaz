extends RefCounted
# Модель топляка: огромное раздутое тело, покрытое бронёй из грибных пластин,
# толстые руки и ноги, вместо головы — бесформенный нарост. Ростом ~2,3 м.
# Возвращает те же части, что и clicker_model.gd: legs, arms, torso, head.

const TORSO_LEAN := -0.3
const ARM_BASE := 0.5
const HIP_Y := 1.05

static func _mat(color: Color, rough := 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m

static func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 12
	s.rings = 6
	return s

static func _capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	c.radial_segments = 10
	c.rings = 4
	return c

static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi

# Броневая пластина: сплюснутая сфера, «прилипшая» к поверхности
static func _plate(parent: Node3D, mat: Material, pos: Vector3, r: float, rng: RandomNumberGenerator) -> void:
	var n := pos.normalized() if pos.length() > 0.001 else Vector3.BACK
	var mi := _add(parent, _sphere(r), mat, pos)
	# разворачиваем плоской стороной наружу (локальная ось Z смотрит от тела)
	mi.basis = Basis.looking_at(-n, Vector3.UP if absf(n.y) < 0.95 else Vector3.RIGHT)
	mi.scale = Vector3(1.0, rng.randf_range(0.7, 1.1), 0.45)

static func build(root: Node3D, seed_value := 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	var t := rng.randf_range(-0.03, 0.03)
	var skin := _mat(Color(0.36 + t, 0.3 + t, 0.22), 0.9)            # раздутая кожа
	var plate := _mat(Color(0.5 + t, 0.42 + t, 0.28), 0.65)          # грибная броня
	var plate_dark := _mat(Color(0.3, 0.24, 0.16), 0.7)
	var flesh := _mat(Color(0.48, 0.14, 0.1), 0.45)                  # мокрая плоть в трещинах
	var sac := _mat(Color(0.62, 0.58, 0.3), 0.4)                     # споровые мешки
	var rag := _mat(Color(0.1, 0.1, 0.09), 0.95)

	# ---------- Таз ----------
	var hips := Node3D.new()
	hips.position = Vector3(0, HIP_Y, 0)
	root.add_child(hips)
	_add(hips, _sphere(0.36), skin, Vector3.ZERO, Vector3.ZERO, Vector3(1.3, 0.8, 1.0))
	_add(hips, _sphere(0.37), rag, Vector3(0, -0.05, 0), Vector3.ZERO, Vector3(1.28, 0.55, 1.02))

	# ---------- Ноги: толстые тумбы ----------
	var legs: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.24, HIP_Y, 0)
		root.add_child(leg)
		_add(leg, _capsule(0.17, 0.75), skin, Vector3(0, -0.3, 0))
		_add(leg, _capsule(0.14, 0.6), skin, Vector3(0, -0.72, 0))
		_add(leg, _sphere(0.16), plate_dark, Vector3(0, -0.98, -0.06), Vector3.ZERO, Vector3(1.0, 0.45, 1.5))
		for i in 3:
			_plate(leg, plate, Vector3(side * 0.13, -0.2 - i * 0.25, rng.randf_range(-0.1, 0.05)), 0.09, rng)
		legs.append(leg)

	# ---------- Туловище: огромный горб из брони ----------
	var torso := Node3D.new()
	torso.position = Vector3(0, HIP_Y, 0)
	torso.rotation.x = TORSO_LEAN
	root.add_child(torso)
	_add(torso, _capsule(0.42, 1.15), skin, Vector3(0, 0.5, 0), Vector3.ZERO, Vector3(1.35, 1.0, 1.1))
	_add(torso, _sphere(0.4), skin, Vector3(0, 0.82, 0.12), Vector3.ZERO, Vector3(1.4, 0.9, 1.1))   # горб
	# Пластины по спине, бокам и плечам
	for i in 22:
		var a := rng.randf_range(-PI * 0.85, PI * 0.85)    # вокруг тела, спереди реже
		var y := rng.randf_range(0.1, 1.05)
		var p := Vector3(sin(a) * 0.56, y, cos(a) * 0.48)
		_plate(torso, plate if i % 3 else plate_dark, p, rng.randf_range(0.1, 0.17), rng)
	# Трещины с плотью и споровые мешки, из которых он достаёт бомбы
	for i in 5:
		var a := rng.randf_range(-PI, PI)
		_add(torso, _sphere(rng.randf_range(0.05, 0.08)), flesh, Vector3(sin(a) * 0.5, rng.randf_range(0.2, 0.9), cos(a) * 0.45))
	for side in [-1.0, 1.0]:
		_add(torso, _sphere(0.1), sac, Vector3(side * 0.5, 0.35, -0.12), Vector3.ZERO, Vector3(0.9, 1.1, 0.9))

	# ---------- Руки: длинные и толстые ----------
	var arms: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.62, 0.95, -0.05)
		arm.rotation.x = ARM_BASE
		arm.rotation.z = side * 0.25
		torso.add_child(arm)
		_add(arm, _sphere(0.2), plate, Vector3.ZERO, Vector3.ZERO, Vector3(1.1, 0.9, 1.1))   # плечо
		_add(arm, _capsule(0.14, 0.6), skin, Vector3(0, -0.3, 0))
		_add(arm, _capsule(0.12, 0.6), skin, Vector3(0, -0.72, 0))
		_add(arm, _sphere(0.15), skin, Vector3(0, -1.05, 0), Vector3.ZERO, Vector3(1.1, 1.2, 0.9))   # кулачище
		for i in 3:
			_plate(arm, plate, Vector3(side * 0.12, -0.25 - i * 0.25, 0.05), 0.08, rng)
		arms.append(arm)

	# ---------- Голова: бесформенный нарост без лица ----------
	var head := Node3D.new()
	head.position = Vector3(0, 1.15, -0.25)
	head.rotation.x = 0.25
	torso.add_child(head)
	_add(head, _sphere(0.24), plate_dark, Vector3.ZERO, Vector3.ZERO, Vector3(1.0, 0.9, 1.0))
	for i in 7:
		var a := TAU * i / 7.0
		_add(head, _sphere(rng.randf_range(0.09, 0.13)), plate, Vector3(cos(a) * 0.17, sin(a) * 0.14 + 0.05, rng.randf_range(-0.12, 0.05)))
	_add(head, _sphere(0.08), flesh, Vector3(0, -0.06, -0.2), Vector3.ZERO, Vector3(1.4, 0.7, 0.6))   # пасть

	return {"legs": legs, "arms": arms, "torso": torso, "head": head}
