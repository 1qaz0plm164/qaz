extends RefCounted
# Модель бандита: здоровый человек в одежде выживальщика, бандана на лице,
# шапка или кепка, в руках оружие. Всё из простых фигур.
#   weapon: "bat" | "pistol" | "shotgun" | "rifle"
# Возвращает части для анимации: legs, arms [левая, правая], torso, head, gun, muzzle

const JACKETS := [Color(0.3, 0.2, 0.12), Color(0.2, 0.24, 0.16), Color(0.16, 0.18, 0.24), Color(0.22, 0.22, 0.22), Color(0.35, 0.3, 0.22)]
const PANTS := [Color(0.16, 0.2, 0.3), Color(0.12, 0.12, 0.12), Color(0.25, 0.22, 0.16), Color(0.2, 0.22, 0.18)]
const SKINS := [Color(0.85, 0.66, 0.52), Color(0.72, 0.53, 0.4), Color(0.55, 0.38, 0.26), Color(0.9, 0.74, 0.62)]
const MASKS := [Color(0.5, 0.08, 0.06), Color(0.08, 0.08, 0.08), Color(0.25, 0.28, 0.2), Color(0.3, 0.3, 0.32)]

static func _mat(color: Color, rough := 0.85, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metallic
	return m

static func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 12
	s.rings = 6
	return s

static func _capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	c.radial_segments = 10
	c.rings = 4
	return c

static func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b

static func _tube(r: float, length: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = length
	c.radial_segments = 8
	return c

static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi

static func build(root: Node3D, weapon: String, seed_value := 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var big := weapon == "bat"         # громила крупнее
	var w := 1.18 if big else 1.0

	var skin := _mat(SKINS[rng.randi() % SKINS.size()], 0.7)
	var jacket := _mat(JACKETS[rng.randi() % JACKETS.size()], 0.9)
	var pants := _mat(PANTS[rng.randi() % PANTS.size()], 0.95)
	var boots := _mat(Color(0.08, 0.06, 0.05), 0.8)
	var mask := _mat(MASKS[rng.randi() % MASKS.size()], 0.95)
	var gear := _mat(Color(0.22, 0.2, 0.14), 0.9)                 # разгрузка, ремни
	var hair := _mat(Color(0.1, 0.07, 0.05), 0.95)
	var eye := _mat(Color(0.05, 0.05, 0.05), 0.4)

	# ---------- Ноги ----------
	var legs: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.11 * w, 0.95, 0)
		root.add_child(leg)
		_add(leg, _capsule(0.085 * w, 0.95), pants, Vector3(0, -0.45, 0))
		_add(leg, _box(Vector3(0.13, 0.1, 0.28)), boots, Vector3(0, -0.9, -0.05))
		legs.append(leg)

	# ---------- Туловище ----------
	var torso := Node3D.new()
	torso.position = Vector3(0, 0.95, 0)
	root.add_child(torso)
	_add(torso, _box(Vector3(0.36 * w, 0.2, 0.22 * w)), pants, Vector3(0, 0.02, 0))          # таз
	_add(torso, _capsule(0.18 * w, 0.72), jacket, Vector3(0, 0.38, 0), Vector3.ZERO, Vector3(1.2, 1.0, 0.8))
	if weapon == "rifle" or weapon == "shotgun":
		# разгрузочный жилет с подсумками
		_add(torso, _box(Vector3(0.4, 0.38, 0.3)), gear, Vector3(0, 0.42, 0))
		for i in 3:
			_add(torso, _box(Vector3(0.08, 0.1, 0.05)), gear, Vector3(-0.1 + i * 0.1, 0.36, -0.17))
	else:
		# ремень через плечо
		_add(torso, _box(Vector3(0.05, 0.6, 0.27 * w)), gear, Vector3(0, 0.4, 0), Vector3(0, 0, 0.6))

	# ---------- Руки ----------
	var arms: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.26 * w, 0.66, 0)
		torso.add_child(arm)
		_add(arm, _capsule(0.07 * w, 0.4), jacket, Vector3(0, -0.17, 0))
		_add(arm, _capsule(0.055 * w, 0.36), jacket, Vector3(0, -0.44, 0))
		_add(arm, _sphere(0.055), skin, Vector3(0, -0.64, 0), Vector3.ZERO, Vector3(0.9, 1.1, 0.8))   # кисть
		arms.append(arm)

	# ---------- Голова ----------
	var head := Node3D.new()
	head.position = Vector3(0, 0.86, 0)
	torso.add_child(head)
	_add(head, _capsule(0.05, 0.14), skin, Vector3(0, -0.1, 0))
	_add(head, _sphere(0.115), skin, Vector3(0, 0.03, 0), Vector3.ZERO, Vector3(0.9, 1.1, 1.0))
	_add(head, _sphere(0.016), eye, Vector3(-0.04, 0.05, -0.1))
	_add(head, _sphere(0.016), eye, Vector3(0.04, 0.05, -0.1))
	# бандана на нижней половине лица
	_add(head, _sphere(0.118), mask, Vector3(0, -0.015, -0.005), Vector3.ZERO, Vector3(0.93, 0.62, 1.02))
	# головной убор: шапка или кепка
	if rng.randf() < 0.5:
		_add(head, _sphere(0.122), mask if rng.randf() < 0.5 else jacket, Vector3(0, 0.09, 0.005), Vector3.ZERO, Vector3(0.95, 0.75, 1.0))
	else:
		_add(head, _sphere(0.12), hair, Vector3(0, 0.08, 0.01), Vector3.ZERO, Vector3(0.94, 0.7, 1.0))
		_add(head, _box(Vector3(0.16, 0.015, 0.1)), jacket, Vector3(0, 0.1, -0.12))   # козырёк

	# ---------- Оружие в правой руке (ствол вдоль -Z оружия) ----------
	var gun := Node3D.new()
	gun.position = Vector3(0, -0.64, 0)
	gun.rotation.x = -PI * 0.5            # -Z оружия смотрит вдоль руки
	arms[1].add_child(gun)
	var metal := _mat(Color(0.08, 0.08, 0.09), 0.4, 0.7)
	var wood := _mat(Color(0.3, 0.18, 0.08), 0.75)
	var length := 0.2
	match weapon:
		"bat":
			var bat := _tube(0.025, 0.75)
			bat.top_radius = 0.045             # толстый конец (смотрит от руки)
			_add(gun, bat, wood, Vector3(0, 0, -0.32), Vector3(-PI * 0.5, 0, 0))
			length = 0.7
		"pistol":
			_add(gun, _box(Vector3(0.03, 0.045, 0.18)), metal, Vector3(0, 0.03, -0.06))
			_add(gun, _box(Vector3(0.028, 0.09, 0.04)), metal, Vector3(0, -0.02, 0.0), Vector3(0.2, 0, 0))
			length = 0.16
		"shotgun":
			_add(gun, _tube(0.016, 0.62), metal, Vector3(0, 0.03, -0.35), Vector3(PI * 0.5, 0, 0))
			_add(gun, _box(Vector3(0.05, 0.05, 0.12)), wood, Vector3(0, 0.0, -0.3))             # цевьё
			_add(gun, _box(Vector3(0.05, 0.07, 0.2)), metal, Vector3(0, 0.02, -0.02))
			_add(gun, _box(Vector3(0.045, 0.09, 0.3)), wood, Vector3(0, -0.02, 0.2), Vector3(0.12, 0, 0))   # приклад
			length = 0.66
		"rifle":
			_add(gun, _box(Vector3(0.05, 0.08, 0.32)), metal, Vector3(0, 0.02, -0.08))
			_add(gun, _tube(0.013, 0.36), metal, Vector3(0, 0.035, -0.42), Vector3(PI * 0.5, 0, 0))
			_add(gun, _box(Vector3(0.035, 0.14, 0.06)), metal, Vector3(0, -0.07, -0.12), Vector3(-0.25, 0, 0))   # магазин
			_add(gun, _box(Vector3(0.04, 0.08, 0.24)), gear, Vector3(0, -0.01, 0.2))                            # приклад
			length = 0.6
	var muzzle := Node3D.new()
	muzzle.position = Vector3(0, 0.03, -length)
	gun.add_child(muzzle)

	return {"legs": legs, "arms": arms, "torso": torso, "head": head, "gun": gun, "muzzle": muzzle}
