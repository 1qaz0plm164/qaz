extends RefCounted
# Строит модель монстра в стиле «щелкуна»: сгорбленное худое тело,
# длинные руки и грибной «цветок» из плоти вместо лица (глаз нет).
# Всё собирается из простых фигур, никаких внешних моделей не нужно.
#
# Возвращает словарь с частями тела, чтобы enemy.gd мог их анимировать:
#   legs [левая, правая], arms [левая, правая], torso, head

const TORSO_LEAN := -0.55   # наклон туловища вперёд (минус = вперёд)
const ARM_BASE := 0.95      # поза рук относительно туловища (свисают вперёд)

static func _mat(color: Color, rough := 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	return m

static func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 12
	s.rings = 6
	return s

static func _capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	c.radial_segments = 10
	c.rings = 4
	return c

static func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b

static func _add(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	parent.add_child(mi)
	return mi

static func build(root: Node3D, seed_value := 0) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	# Лёгкая индивидуальность: у каждого монстра чуть другой оттенок
	var tint := rng.randf_range(-0.04, 0.04)
	var skin := _mat(Color(0.3 + tint, 0.32 + tint, 0.26), 0.9)        # серо-зелёная кожа
	var cloth := _mat(Color(0.12 + tint, 0.13 + tint, 0.13), 0.95)       # рваная куртка
	var pants := _mat(Color(0.13, 0.12, 0.11), 0.95)                    # грязные штаны
	var flesh := _mat(Color(0.5, 0.17, 0.13), 0.5)                     # грибная плоть
	var flesh_dark := _mat(Color(0.26, 0.06, 0.07), 0.45)               # тёмная глубина «цветка»
	var spore := _mat(Color(0.64, 0.5, 0.3), 0.7)                       # наросты-споры
	var tooth := _mat(Color(0.78, 0.72, 0.6), 0.5)                      # зубы

	# ---------- Таз ----------
	var hips := Node3D.new()
	hips.position = Vector3(0, 0.95, 0)
	root.add_child(hips)
	_add(hips, _box(Vector3(0.38, 0.2, 0.22)), pants)

	# ---------- Ноги ----------
	var legs: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.12, 0.95, 0)
		root.add_child(leg)
		_add(leg, _capsule(0.085, 0.95), pants, Vector3(0, -0.45, 0))
		_add(leg, _box(Vector3(0.13, 0.08, 0.28)), skin, Vector3(0, -0.9, -0.05))   # ступня
		legs.append(leg)

	# ---------- Туловище (наклонено вперёд — сгорбленная поза) ----------
	var torso := Node3D.new()
	torso.position = Vector3(0, 0.95, 0)
	torso.rotation.x = TORSO_LEAN
	root.add_child(torso)
	_add(torso, _capsule(0.19, 0.8), cloth, Vector3(0, 0.4, 0), Vector3.ZERO, Vector3(1.25, 1.0, 0.8))
	# Наросты-споры на спине и плечах
	for i in 7:
		var p := Vector3(rng.randf_range(-0.22, 0.22), rng.randf_range(0.2, 0.75), rng.randf_range(0.08, 0.17))
		_add(torso, _sphere(rng.randf_range(0.03, 0.06)), spore, p)
	_add(torso, _sphere(0.07), flesh, Vector3(-0.2, 0.72, 0.02), Vector3.ZERO, Vector3(1.2, 0.8, 1.0))

	# ---------- Руки (длинные, свисают вперёд) ----------
	var arms: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.28, 0.7, 0)
		arm.rotation.x = ARM_BASE
		torso.add_child(arm)
		_add(arm, _capsule(0.062, 0.8), skin, Vector3(0, -0.38, 0))
		_add(arm, _sphere(0.075), skin, Vector3(0, -0.8, 0), Vector3.ZERO, Vector3(0.9, 1.3, 0.8))   # кисть
		# Пальцы-когти
		for f in 3:
			_add(arm, _box(Vector3(0.015, 0.1, 0.015)), tooth, Vector3((f - 1) * 0.03, -0.9, 0.0))
		arms.append(arm)

	# ---------- Голова с грибным «цветком» ----------
	var head := Node3D.new()
	head.position = Vector3(0, 0.98, -0.1)
	head.rotation.x = 0.35   # голова опущена вперёд, как у щелкуна
	torso.add_child(head)
	_add(head, _sphere(0.12), skin)   # череп (почти весь закрыт грибом)

	# Лепестки «цветка» — раскрываются вперёд, как у щелкуна
	var petals := 9
	for i in petals:
		var pivot := Node3D.new()
		pivot.rotation.z = TAU * i / petals
		head.add_child(pivot)
		var petal := _add(pivot, _sphere(0.1), flesh, Vector3(0, 0.15, -0.09), Vector3(-0.6, 0, 0), Vector3(0.95, 1.9, 0.5))
		petal.scale *= rng.randf_range(0.9, 1.15)
	# Тёмная «сердцевина» и бугры внутри цветка
	_add(head, _sphere(0.14), flesh_dark, Vector3(0, 0, -0.1), Vector3.ZERO, Vector3(1.0, 1.0, 0.7))
	for i in 6:
		var a := TAU * i / 6.0
		_add(head, _sphere(0.04), flesh, Vector3(cos(a) * 0.08, sin(a) * 0.08, -0.17))
	# Нижняя челюсть с зубами торчит под цветком
	_add(head, _box(Vector3(0.1, 0.035, 0.09)), skin, Vector3(0, -0.15, -0.06))
	for i in 5:
		_add(head, _box(Vector3(0.01, 0.03, 0.01)), tooth, Vector3((i - 2) * 0.02, -0.13, -0.1))

	return {"legs": legs, "arms": arms, "torso": torso, "head": head}
